# Source provenance and adaptations

## Research implementation

`masloop_demo/vendor/paper_schema.py` is copied byte-for-byte from:

`MAS_Loop_anonymous.zip → MAS_Loop/verl/mas_loop_rl/schema.py`

The original runtime contains legacy normalization behavior. `core.py` wraps it to reject invalid endpoints, disconnected graphs, duplicate edges, unsupported tools and ungrounded edits before live execution. Atomic AddAgent wiring to the unchanged aggregator is implemented in this wrapper to match `sections/3_mas_loop.tex`.

The API executor, server, CLI, tools and UI are new deployment adapters. They replace training-time local model services and benchmark-specific execution with OpenCode chat-completions calls and a small allowlisted tool set. They do not claim to reproduce trained policy behavior.

## Paper and assets

- `blog/assets/paper.pdf`: unchanged supplied `_ICLR_27__MAS_Loop_latest.pdf`.
- Method, background and ablation PNGs: rendered from PDFs in `_ICLR_27__MAS_Loop.zip/figures`.
- Blog numerical results: `sections/4_main_experiments.tex` and `sections/5_data_resources.tex`, checked against the supplied PDF.
- `web/paper-case.json`: condensed and annotated `sections/case_study.tex`. Source and updated node responses are documented excerpts; the compact graph, structured diagnosis and animation are presentation reconstructions. No raw corpus or timings are invented.

## Question bank

`web/questions.json` derives from `Skill-MAS-Demo.zip/Skill-MAS-Demo/part2/data/questions.json`. IDs and dataset labels are preserved. The malformed appended literal `/nPlease output ...` format instruction is removed from AIME prompts; problem text is unchanged.

Counts: AIME2425 = 57; HLEMATH = 168; DeepResearchBench = 84. These reflect the reference demo's selected prompts, not full dataset sizes or MAS-Loop evaluation splits.

`data/answer_keys.json` contains exact matched AIME answer labels from the same reference archive's `part2/data/aime.jsonl`. It is not served as a web asset. The server uses it only after the Refiner and both executions finish.

The evidence-puzzle starter is synthetic and explicitly labeled. The two math starters come from the reference AIME data.

## Notices

The supplied MAS-Loop archive has no top-level license. No replacement license has been invented. The research code package retains all original files and bundled `verl/LICENSE` and `verl/Notice.txt`. Dataset ownership and applicable terms remain with their original authors. This release is prepared for the source owner's review and deployment.
