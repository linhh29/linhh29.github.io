# Lightweight inference adapter

See the root README for CLI instructions. This directory contains the runtime and core tests; use the separate MAS-Loop-Demo package for the web application and full HTTP test suite.

```bash
python3 -m unittest discover -s tests -v
```

No trained checkpoints or provider credentials are included.
