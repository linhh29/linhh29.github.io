import json, unittest
from masloop_demo.core import validate_graph, compile_patch, calculator, loop
from masloop_demo.evaluation import final_integer

def graph():
    return {'agents':[{'id':x,'role':'Solve carefully using the problem constraints.','tools':[],'budget':1,'execution_mode':'llm_only'} for x in ['solver','final']], 'edges':[{'from':'solver','to':'final','type':'data_flow'}], 'aggregation':'final','topology':'dag','max_cost':2,'max_iterations':1}

def decision(op):
    return {'stage1_localization':{'evidence':[{'agent_id':'solver','execution_index':0,'quote':'I ignored the second condition.'}]},'stage2_causal_model':{'causal_explanation':'Constraint omission'},'patch':[op]}

TRACE=[{'agent_id':'solver','output':'I ignored the second condition.'}]

class CoreTests(unittest.TestCase):
    def test_cycle_rejected(self):
        g=graph();g['edges'].append({'from':'final','to':'solver','type':'data_flow'})
        with self.assertRaisesRegex(ValueError,'Cycle'):validate_graph(g)
    def test_bad_endpoint_rejected_before_normalization(self):
        g=graph();g['edges'][0]['to']='missing'
        with self.assertRaises(ValueError):validate_graph(g)
    def test_disconnected_agent(self):
        g=graph();g['edges']=[]
        with self.assertRaisesRegex(ValueError,'path'):validate_graph(g)
    def test_add_agent_atomic(self):
        g=graph();updated=compile_patch(g,decision({'op':'add_agent','agent_id':'check','role':'Check all constraints.','budget':1}),TRACE)
        self.assertEqual(updated['aggregation'],'final');self.assertIn({'from':'check','to':'final','type':'data_flow'},updated['edges']);self.assertEqual(len(g['agents']),2)
    def test_fabricated_evidence_rejected(self):
        d=decision({'op':'rewrite_role','agent_id':'solver','role':'Check all conditions.'});d['stage1_localization']['evidence'][0]['quote']='This quote never appeared.'
        with self.assertRaisesRegex(ValueError,'quote'):compile_patch(graph(),d,TRACE)
    def test_wrong_target_rejected(self):
        with self.assertRaisesRegex(ValueError,'target'):compile_patch(graph(),decision({'op':'rewrite_role','agent_id':'final','role':'Check all conditions.'}),TRACE)
    def test_remove_only_edge_rejected(self):
        with self.assertRaisesRegex(ValueError,'path'):compile_patch(graph(),decision({'op':'remove_edge','from':'solver','to':'final'}),TRACE)
    def test_multiple_ops_rejected(self):
        d=decision({'op':'accept'});d['patch'].append({'op':'accept'})
        with self.assertRaisesRegex(ValueError,'one'):compile_patch(graph(),d,TRACE)
    def test_tool_and_budget_limits(self):
        for op in [{'op':'replace_tool','agent_id':'solver','old_tool':'','new_tool':'shell'},{'op':'change_budget','agent_id':'solver','budget':99}]:
            with self.assertRaises(ValueError):compile_patch(graph(),decision(op),TRACE)
    def test_supported_edits(self):
        for op in [{'op':'rewrite_role','agent_id':'solver','role':'Check every conjunct before selecting an answer.'},{'op':'change_budget','agent_id':'solver','budget':2},{'op':'replace_tool','agent_id':'solver','old_tool':'','new_tool':'calculator'},{'op':'accept'}]:validate_graph(compile_patch(graph(),decision(op),TRACE))
    def test_calculator_not_code_execution(self):
        self.assertEqual(calculator('100//3+100//5-100//15'),'47')
        for expression in ["__import__('os').system('id')",'2**999999','[0]*100','(1).__class__','9'*200]:
            with self.assertRaises(ValueError):calculator(expression)
    def test_end_to_end_gold_free_independent_rerun(self):
        class Fake:
            usage=[]
            def __init__(self):self.agent_calls=0;self.refiner_payload=None
            def call(self,system,payload,role='agent',max_tokens=0):
                if role=='orchestrator':return json.dumps(graph())
                if role=='refiner':self.refiner_payload=payload;return json.dumps(decision({'op':'rewrite_role','agent_id':'solver','role':'Check both conditions before answering.'}))
                self.agent_calls+=1
                return TRACE[0]['output'] if self.agent_calls==1 else 'FINAL: 117'
        client=Fake();events=[];r=loop('Find a solution to both constraints.',client=client,emit=lambda k,d:events.append(k))
        self.assertEqual(client.agent_calls,4);self.assertEqual(r['patch_status'],'applied');self.assertEqual(r['updated']['answer'],'FINAL: 117');self.assertEqual(events[-1],'complete');self.assertNotIn('gold',client.refiner_payload);self.assertNotIn('score',client.refiner_payload)
    def test_accept_still_reexecutes(self):
        class Fake:
            usage=[]
            def __init__(self):self.calls=0
            def call(self,system,payload,role='agent',max_tokens=0):
                if role=='orchestrator':return json.dumps(graph())
                if role=='refiner':return json.dumps({'patch':[{'op':'accept'}]})
                self.calls+=1;return str(self.calls)
        client=Fake();r=loop('Solve the same task.',client=client)
        self.assertEqual(client.calls,4);self.assertEqual(r['source_graph'],r['updated_graph']);self.assertEqual(r['patch_status'],'accepted')
    def test_invalid_patch_preserves_source(self):
        class Fake:
            usage=[]
            def call(self,system,payload,role='agent',max_tokens=0):
                if role=='orchestrator':return json.dumps(graph())
                if role=='refiner':return '{"patch":[{"op":"shell"}]}'
                return 'FINAL: 7'
        r=loop('Test invalid action.',client=Fake());self.assertEqual(r['patch_status'],'invalid');self.assertEqual(r['source_graph'],r['updated_graph'])
    def test_final_integer_parser(self):
        self.assertEqual(final_integer('There are 100 possibilities.\nFINAL: 117'),'117');self.assertEqual(final_integer(r'\boxed{007}'),'7');self.assertIsNone(final_integer('There could be 117 cases.'))

if __name__=='__main__':unittest.main()
