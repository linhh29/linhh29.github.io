"""A small API-backed implementation of the MAS-Loop inference lifecycle."""
