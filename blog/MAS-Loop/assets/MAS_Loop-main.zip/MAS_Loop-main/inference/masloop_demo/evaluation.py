"""Optional exact-match evaluation, applied only AFTER the paired execution."""
import json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]

def final_integer(text):
    values=re.findall(r'FINAL:\s*\$?\s*(?:\\boxed\{)?\s*(-?\d+)\s*\}?\s*\$?\s*[.]?\s*$',text,re.I|re.M)
    if not values: values=re.findall(r'\\boxed\{\s*(-?\d+)\s*\}',text)
    return str(int(values[-1])) if values else None

def annotate(result,dataset_id):
    keys=json.loads((ROOT/'data/answer_keys.json').read_text())
    questions=json.loads((ROOT/'web/questions.json').read_text())
    q=next((x for x in questions if x['id']==dataset_id),None)
    if not q or q['question'].strip()!=result['task'].strip() or dataset_id not in keys: return result
    expected=str(int(keys[dataset_id]));scores={}
    for phase in ('source','updated'):
        answer=final_integer(result[phase]['answer'])
        scores[phase]={'extracted':answer,'correct':answer==expected if answer is not None else None}
    result['reference_evaluation']={'dataset_id':dataset_id,'reference_answer':expected,'method':'exact integer match; unparsed answers are unscored',**scores}
    result['evaluation']='AIME reference evaluation (performed after refinement): '+', '.join(f'{phase} = '+('unscored (format)' if scores[phase]['correct'] is None else 'correct' if scores[phase]['correct'] else 'incorrect') for phase in ('source','updated'))+'. Gold answers were not sent to any model. A single pair does not estimate benchmark performance.'
    return result
