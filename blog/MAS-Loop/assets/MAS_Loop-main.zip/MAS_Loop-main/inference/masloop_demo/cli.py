import argparse, json, pathlib
from .server import load_env, ROOT
from .core import loop

def main():
    p=argparse.ArgumentParser(description='Execute a single MAS-Loop source/refinement pair')
    p.add_argument('--task',required=True);p.add_argument('--context-file');p.add_argument('--output',default='run.json')
    a=p.parse_args();load_env(ROOT/'.env')
    context=pathlib.Path(a.context_file).read_text() if a.context_file else ''
    result=loop(a.task,context)
    pathlib.Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(result['updated']['answer']);print('Saved:',a.output)

if __name__=='__main__': main()
