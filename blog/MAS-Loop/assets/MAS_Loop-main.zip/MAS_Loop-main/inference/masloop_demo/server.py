"""Zero-dependency HTTP server. Use one process behind a TLS reverse proxy."""
from __future__ import annotations
import collections, hmac, json, mimetypes, os, pathlib, threading, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from .core import Client, ProviderError, loop
from .evaluation import annotate
ROOT=pathlib.Path(__file__).resolve().parents[1]


def load_env(path):
    if not path.exists(): return
    for line in path.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        k,v=line.split('=',1)
        if k.strip().replace('_','').isalnum(): os.environ.setdefault(k.strip(),v.strip().strip('\"\''))


load_env(ROOT/'.env')
# Accept the reference Skill-MAS configuration names as migration aliases.
for target, aliases in {
 'MAS_LOOP_API_KEY':['SKILL_MAS_DEMO_API_KEY','OPENAI_API_KEY'],
 'MAS_LOOP_BASE_URL':['SKILL_MAS_DEMO_BASE_URL','OPENAI_API_BASE'],
 'MAS_LOOP_MODEL':['SKILL_MAS_DEMO_MODEL'],
}.items():
    for alias in aliases:
        if target not in os.environ and os.getenv(alias): os.environ[target]=os.environ[alias]
LIMIT=int(os.getenv('MAS_LOOP_RUNS_PER_HOUR','10'))
SLOTS=threading.BoundedSemaphore(int(os.getenv('MAS_LOOP_CONCURRENCY','2')))
RATE=collections.OrderedDict(); LOCK=threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self, fmt, *args):
        # Avoid logging tasks, access tokens, or provider responses.
        pass
    def common(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
    def send_json(self,status,obj):
        data=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(status);self.common();self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
    def do_GET(self):
        route=urllib.parse.urlsplit(self.path).path
        if route=='/api/health': return self.send_json(200,{'ok':True,'live_configured':bool(Client().key),'model':Client().model,'access_required':bool(os.getenv('MAS_LOOP_ACCESS_TOKEN'))})
        if route=='/api/examples': return self.send_json(200,json.loads((ROOT/'web/examples.json').read_text()))
        if route.startswith('/api/'): return self.send_json(404,{'error':'Not found'})
        base=ROOT/'web'
        if route.startswith('/blog/'):
            base=ROOT/'blog'; route=route[5:]
        path=(base/urllib.parse.unquote(route).lstrip('/')).resolve()
        if path.is_dir(): path=path/'index.html'
        if not path.is_relative_to(base.resolve()) or not path.is_file(): return self.send_json(404,{'error':'Not found'})
        data=path.read_bytes();self.send_response(200);self.common();self.send_header('Content-Type',(mimetypes.guess_type(str(path))[0] or 'application/octet-stream')+'; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_POST(self):
        if self.path!='/api/run': return self.send_json(404,{'error':'Not found'})
        origin=self.headers.get('Origin')
        if origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host'): return self.send_json(403,{'error':'Cross-origin requests are disabled'})
        token=os.getenv('MAS_LOOP_ACCESS_TOKEN','')
        if token and not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token): return self.send_json(401,{'error':'Enter the demo access token provided by the site owner.'})
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=40000: return self.send_json(413,{'error':'Request size must be 1–40000 bytes'})
            self.connection.settimeout(15)
            payload=json.loads(self.rfile.read(size))
            task,context=payload.get('task',''),payload.get('context','')
            if not isinstance(task,str) or not 8<=len(task.strip())<=3000: raise ValueError('Task must contain 8–3000 characters')
            if not isinstance(context,str) or len(context)>16000: raise ValueError('Context limit is 16000 characters')
        except (ValueError,AttributeError,TimeoutError): return self.send_json(400,{'error':'Invalid request: task 8–3000 characters; context at most 16000 characters.'})
        if not Client().key: return self.send_json(503,{'error':'Live inference is not configured. Set MAS_LOOP_API_KEY in the server .env file. The paper walkthrough is available without an API key.'})
        if not SLOTS.acquire(blocking=False): return self.send_json(429,{'error':'All execution slots are busy. Please retry shortly.'})
        ip=self.client_address[0] # Forwarded headers are deliberately not trusted.
        now=time.monotonic()
        with LOCK:
            visits=[t for t in RATE.get(ip,[]) if t>now-3600]
            if len(visits)>=LIMIT:
                SLOTS.release();return self.send_json(429,{'error':'Hourly run limit reached.'})
            visits.append(now);RATE[ip]=visits;RATE.move_to_end(ip)
            while len(RATE)>10000: RATE.popitem(last=False)
        disconnected=threading.Event();write_lock=threading.Lock()
        self.connection.settimeout(30)
        self.send_response(200);self.common();self.send_header('Content-Type','application/x-ndjson; charset=utf-8');self.send_header('Cache-Control','no-cache, no-store');self.send_header('X-Accel-Buffering','no');self.send_header('Connection','close');self.end_headers();self.close_connection=True
        def emit(kind,data):
            if kind=='complete': annotate(data,payload.get('dataset_id'))
            with write_lock:
                if disconnected.is_set(): raise InterruptedError('Client disconnected')
                try: self.wfile.write((json.dumps({'type':kind,'data':data},ensure_ascii=False)+'\n').encode());self.wfile.flush()
                except (BrokenPipeError,ConnectionError,OSError): disconnected.set();raise InterruptedError('Client disconnected')
        finished=threading.Event()
        def heartbeat():
            while not finished.wait(10):
                try: emit('heartbeat',{})
                except InterruptedError: return
        threading.Thread(target=heartbeat,daemon=True).start()
        try: loop(task.strip(),context,emit,cancelled=disconnected.is_set)
        except InterruptedError: pass
        except Exception as e:
            message=str(e) if isinstance(e,(ProviderError,ValueError)) else 'The run failed. Check the server configuration and try again.'
            try: emit('error',{'message':message})
            except InterruptedError: pass
        finally: finished.set();SLOTS.release()


def main():
    host=os.getenv('MAS_LOOP_HOST','127.0.0.1');port=int(os.getenv('MAS_LOOP_PORT','9388'))
    server=ThreadingHTTPServer((host,port),Handler);server.daemon_threads=True
    print(f'MAS-Loop: http://{host}:{port} | model={Client().model} | live={bool(Client().key)}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__=='__main__': main()
