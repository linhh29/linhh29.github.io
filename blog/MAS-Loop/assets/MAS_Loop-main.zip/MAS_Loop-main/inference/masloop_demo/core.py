"""Inference adapter; original paper compiler lives in vendor/paper_schema.py."""
from __future__ import annotations
import ast, copy, json, math, operator, os, re, time, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
from .vendor import paper_schema as paper

TOOLS = {'calculator', 'evidence_search'}


def validate_graph(g):
    if not isinstance(g, dict): raise ValueError('Graph must be an object')
    agents, edges = g.get('agents'), g.get('edges')
    if not isinstance(agents, list) or not 1 <= len(agents) <= 6: raise ValueError('Use 1–6 agents')
    if not isinstance(edges, list) or len(edges) > 16: raise ValueError('Use at most 16 edges')
    ids = [a.get('id') for a in agents]
    if any(not isinstance(i, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,47}', i) for i in ids) or len(set(ids)) != len(ids): raise ValueError('Invalid or duplicated agent ID')
    if g.get('aggregation') not in ids: raise ValueError('Missing aggregation agent')
    for a in agents:
        if not isinstance(a.get('role'), str) or not 1 <= len(a['role']) <= 1000: raise ValueError('Invalid role')
        if type(a.get('budget')) is not int or not 1 <= a['budget'] <= 4: raise ValueError('Budget must be 1–4')
        if not isinstance(a.get('tools'), list) or not set(a['tools']) <= TOOLS: raise ValueError('Unavailable tool')
        if a.get('execution_mode') != 'llm_only': raise ValueError('Demo uses llm_only plus explicit tool requests')
    if sum(a['budget'] for a in agents) > 16: raise ValueError('Total reasoning budget exceeds 16')
    seen = set()
    for e in edges:
        pair = (e.get('from'), e.get('to'))
        if pair[0] not in ids or pair[1] not in ids or pair[0] == pair[1] or pair in seen: raise ValueError('Invalid/duplicate edge')
        if e.get('type') not in paper.VALID_EDGE_TYPES: raise ValueError('Invalid edge type')
        seen.add(pair)
    if paper._mas_has_cycle(g): raise ValueError('Cycle detected')
    final = g['aggregation']
    if any(e['from'] == final for e in edges): raise ValueError('Aggregation must be a sink')
    reached = {final}
    while True:
        expanded = reached | {e['from'] for e in edges if e['to'] in reached}
        if expanded == reached: break
        reached = expanded
    if reached != set(ids): raise ValueError('Every agent must have a path to aggregation')
    return g


def compile_patch(source, decision, traces):
    """Reuse the research compiler with strict web adapter checks and atomic AddAgent."""
    ops = decision.get('patch', decision.get('operations', []))
    if not isinstance(ops, list) or len(ops) != 1 or not isinstance(ops[0], dict) or ops[0].get('op') not in paper.VALID_PATCH_OPS:
        raise ValueError('Exactly one canonical operation is required')
    op = ops[0]
    if op['op'] != 'accept':
        evidence = decision.get('stage1_localization', {}).get('evidence', [])
        if not evidence: raise ValueError('A patch needs trajectory evidence')
        for item in evidence:
            idx = item.get('execution_index')
            quote = item.get('quote', '')
            if type(idx) is not int or not 0 <= idx < len(traces): raise ValueError('Unresolved evidence index')
            if item.get('agent_id') != traces[idx]['agent_id']: raise ValueError('Evidence agent mismatch')
            if not isinstance(quote, str) or len(quote.strip()) < 8 or quote not in traces[idx]['output']: raise ValueError('Evidence quote is not in the execution trace')
        aid = op.get('agent_id')
        if op['op'] in {'rewrite_role','change_budget','replace_tool'} and aid not in {t['agent_id'] for t in traces if any(e.get('agent_id') == t['agent_id'] for e in evidence)}:
            raise ValueError('Patch target lacks supporting execution evidence')
    if op['op'] == 'change_budget' and (type(op.get('budget')) is not int or not 1 <= op['budget'] <= 4): raise ValueError('Invalid budget')
    if op['op'] == 'replace_tool' and op.get('new_tool', '') not in TOOLS | {''}: raise ValueError('Tool is unavailable')
    # Preflight on the literal graph prevents legacy normalization from repairing invalid edits.
    candidate = copy.deepcopy(source)
    if op['op'] == 'remove_edge':
        candidate['edges'] = [e for e in candidate['edges'] if not (e['from'] == op.get('from') and e['to'] == op.get('to'))]
        validate_graph(candidate)
    updated, errors = paper.apply_patch(source, copy.deepcopy(decision))
    if errors: raise ValueError('; '.join(errors))
    if op['op'] == 'add_agent':
        added = set(a['id'] for a in updated['agents']) - set(a['id'] for a in source['agents'])
        for aid in added:
            updated['edges'].append({'from': aid, 'to': source['aggregation'], 'type': 'data_flow'})
    validate_graph(updated)
    if op['op'] != 'accept' and updated == paper.normalize_mas(source): raise ValueError('Patch makes no change')
    return updated


def calculator(expression):
    if not isinstance(expression, str) or len(expression) > 180: raise ValueError('Expression too long')
    tree = ast.parse(expression, mode='eval')
    if sum(1 for _ in ast.walk(tree)) > 60: raise ValueError('Expression too complex')
    operations = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
    def visit(n):
        if isinstance(n, ast.Constant) and type(n.value) in (int, float): v = n.value
        elif isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)): v = (-1 if isinstance(n.op, ast.USub) else 1) * visit(n.operand)
        elif isinstance(n, ast.BinOp) and type(n.op) in operations:
            a, b = visit(n.left), visit(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 12: raise ValueError('Exponent limit is 12')
            v = operations[type(n.op)](a, b)
        else: raise ValueError('Only numeric arithmetic is supported')
        if isinstance(v, complex) or not math.isfinite(v) or abs(v) > 1e18: raise ValueError('Numeric range exceeded')
        return v
    return str(visit(tree.body))


def evidence_search(query, context):
    terms = set(re.findall(r'\w+', query.lower()))
    chunks = [x.strip() for x in context.split('\n') if x.strip()]
    ranked = sorted(enumerate(chunks), key=lambda p: -len(terms & set(re.findall(r'\w+', p[1].lower()))))
    return [{'document': i + 1, 'text': s[:1600]} for i, s in ranked[:4] if terms & set(re.findall(r'\w+', s.lower()))]


class ProviderError(Exception): pass


class Client:
    def __init__(self):
        self.base = os.getenv('MAS_LOOP_BASE_URL', 'https://opencode.ai/zen/go/v1').rstrip('/')
        self.key = os.getenv('MAS_LOOP_API_KEY') or os.getenv('OPENAI_API_KEY', '')
        self.model = os.getenv('MAS_LOOP_MODEL', 'deepseek-v4-flash')
        self.usage = []

    def call(self, system, payload, role='agent', max_tokens=1400):
        if not self.key: raise ProviderError('Live inference is not configured. Set MAS_LOOP_API_KEY on the server.')
        model = os.getenv('MAS_LOOP_' + role.upper() + '_MODEL', self.model)
        body = {'model': model, 'messages': [{'role':'system','content':system},{'role':'user','content':json.dumps(payload, ensure_ascii=False)}], 'max_tokens': max_tokens, 'temperature': 0.4}
        req = urllib.request.Request(self.base + '/chat/completions', data=json.dumps(body).encode(), headers={'Authorization': 'Bearer ' + self.key, 'Content-Type':'application/json'})
        for attempt in range(2):
            try:
                with urllib.request.urlopen(req, timeout=90) as r: result = json.load(r)
                choice = result['choices'][0]
                self.usage.append({'role':role, 'model':model, **result.get('usage', {})})
                content = choice['message'].get('content')
                if choice.get('finish_reason') == 'length': raise ProviderError('Model reached its output limit. Increase MAS_LOOP_AGENT_TOKENS or use a shorter task.')
                if not isinstance(content, str) or not content.strip(): raise ProviderError('Provider returned an empty answer.')
                return content
            except urllib.error.HTTPError as e:
                if e.code in (429, 502, 503) and attempt == 0:
                    time.sleep(1); continue
                raise ProviderError(f'Provider returned HTTP {e.code}. Check the server API key, model, quota and endpoint.') from None
            except (urllib.error.URLError, TimeoutError): raise ProviderError('Provider connection failed or timed out.') from None
            except (KeyError, IndexError, json.JSONDecodeError): raise ProviderError('Provider returned an invalid chat-completions response.') from None


def parse_json(text):
    text = re.sub(r'<think>[\s\S]*?</think>', '', text).strip()
    if text.startswith('```'): text = re.sub(r'^```(?:json)?\s*|\s*```$', '', text)
    value = json.loads(text)
    if not isinstance(value, dict): raise ValueError('Expected a JSON object')
    return value


ORCHESTRATOR = '''You are the MAS-Loop Orchestrator. Design a compact task-specific agent DAG; do not answer the task. Return only JSON with agents, edges, aggregation, topology="dag", max_cost=8, max_iterations=1. Use 3 or 4 agents, at most 5. Each agent: id (ASCII identifier), role (specific task responsibility, <=1000 chars), tools (subset of calculator and evidence_search), budget (integer 1 or 2), execution_mode="llm_only". Edges: from, to, type="data_flow". At least one agent is an independent checker. Every node must reach the single final aggregation node, which has no outgoing edges. evidence_search searches only user-supplied context; it is not web browsing. Use it only if context is present. calculator handles numeric arithmetic only. Roles must not contain an answer. The final agent ends with FINAL: <short answer>.'''
REFINER = '''You are the MAS-Loop Refiner. Inspect the task, source graph and actual node outputs. No gold answer, reward or correctness label is available. Localize an observed failure, state a causal hypothesis, and propose exactly ONE bounded operation. Prefer accept if no concrete evidence justifies change. Missing telemetry or uncertainty alone is not failure. Return JSON:
{"stage1_localization":{"source_status":"actionable_failure or preserve","target_id":"id","failure_type":"description","evidence":[{"agent_id":"id","execution_index":0,"quote":"exact verbatim substring >=8 characters from this node output","observation":"why it matters"}]},"stage2_causal_model":{"causal_explanation":"brief evidence-based explanation","counterfactual":"falsifiable expected change"},"stage3_repair_plan":{"repair_goal":"goal","risk":"risk"},"patch":[{"op":"accept"}]}.
The patch has EXACTLY ONE operation from: accept; rewrite_role (agent_id, role); add_agent (agent_id=new unique id, role, budget=1; automatically connected to existing aggregation); add_edge or remove_edge (from,to,type="data_flow"); change_budget (agent_id,budget=1..4); replace_tool (agent_id,old_tool,new_tool). Tools: calculator, evidence_search; empty new_tool disables old tool. All nodes must still reach aggregation. For rewrite_role/change_budget/replace_tool cite that node's output. Never bake the answer into a role; make a reusable repair. Output JSON only, no private reasoning.'''
AGENT = '''Execute your assigned MAS role. Use task/context and only supplied upstream outputs. Give concise evidence and intermediate results, not private chain-of-thought. If you are the final agent, finish with FINAL: <short answer>. You may request one available tool per turn by returning ONLY {"tool":"calculator","input":"arithmetic expression"} or {"tool":"evidence_search","input":"search terms"}. Tools not assigned to you cannot be called. Evidence search uses supplied context only. If tools are exhausted, answer from available evidence. Do not claim to have browsed the web.'''


def execute(graph, task, context, client, emit, phase, cancelled):
    outputs, traces = {}, []
    started = time.monotonic()
    base_tokens = max(128, min(2048, int(os.getenv('MAS_LOOP_AGENT_TOKENS','1400'))))
    def run_agent(a):
        if cancelled(): raise InterruptedError('Run cancelled')
        emit('node_start', {'phase': phase, 'agent_id': a['id']})
        t = time.monotonic()
        payload = {'task':task,'context':context,'role':a['role'],'available_tools':a['tools'],'upstream':{e['from']:outputs[e['from']] for e in graph['edges'] if e['to']==a['id']},'is_final': a['id']==graph['aggregation']}
        tool_trace=[]
        for turn in range(3):
            if cancelled(): raise InterruptedError('Run cancelled')
            output=client.call(AGENT, payload, max_tokens=min(4096, base_tokens*a['budget']))
            try: request=parse_json(output)
            except (ValueError, TypeError): break
            if 'tool' not in request: break
            if turn==2: raise ValueError('Agent exceeded the two-call tool budget')
            name, value=request['tool'],request.get('input','')
            if name not in a['tools']: raise ValueError('Agent requested an unavailable tool')
            try: result=calculator(value) if name=='calculator' else evidence_search(value, context)
            except (ValueError, ArithmeticError, SyntaxError) as e: result={'error': str(e)}
            tool_trace.append({'tool':name,'input':value,'result':result})
            payload['tool_results']=tool_trace
            if turn==1: payload['available_tools']=[]
            emit('tool', {'phase':phase,'agent_id':a['id'],**tool_trace[-1]})
        trace={'agent_id':a['id'],'output':output,'tools':tool_trace,'seconds':round(time.monotonic()-t,2),'dependencies':list(payload['upstream'])}
        emit('node_done', {'phase':phase,**trace})
        return trace
    while len(outputs)<len(graph['agents']):
        ready=[a for a in graph['agents'] if a['id'] not in outputs and all(e['from'] in outputs for e in graph['edges'] if e['to']==a['id'])]
        if not ready: raise ValueError('Graph execution stalled')
        with ThreadPoolExecutor(max_workers=3) as pool:
            batch=list(pool.map(run_agent,ready))
        for trace in batch:
            trace['execution_index']=len(traces)
            traces.append(trace);outputs[trace['agent_id']]=trace['output']
    return {'traces':traces,'answer':outputs[graph['aggregation']],'seconds':round(time.monotonic()-started,2)}


def loop(task, context='', emit=lambda *_:None, client=None, cancelled=lambda:False):
    client=client or Client(); start=time.monotonic()
    def stopped(): return cancelled() or time.monotonic()-start>600
    emit('stage',{'stage':'build','message':'Orchestrator is constructing an executable graph.'})
    graph=validate_graph(parse_json(client.call(ORCHESTRATOR,{'task':task,'context':context},'orchestrator',3000)))
    emit('graph',{'phase':'source','graph':graph})
    source=execute(graph,task,context,client,emit,'source',stopped)
    emit('execution',{'phase':'source',**source})
    if stopped(): raise InterruptedError('Run cancelled')
    emit('stage',{'stage':'refine','message':'Refiner is inspecting the source trajectory, without an answer key.'})
    raw=client.call(REFINER,{'task':task,'context':context,'source_mas':graph,'trajectory':source['traces'],'source_answer':source['answer']},'refiner',3000)
    try:
        decision=parse_json(raw)
        updated=compile_patch(graph,decision,source['traces']); status='accepted' if decision['patch'][0]['op']=='accept' else 'applied'; errors=[]
    except (ValueError, TypeError, KeyError) as e:
        decision={'raw_output':raw};updated=copy.deepcopy(graph);status='invalid';errors=[str(e)]
    emit('patch',{'decision':decision,'status':status,'errors':errors})
    emit('graph',{'phase':'updated','graph':updated})
    emit('stage',{'stage':'rerun','message':'Executing the updated graph independently on the same task.'})
    rerun=execute(updated,task,context,client,emit,'updated',stopped)
    emit('execution',{'phase':'updated',**rerun})
    result={'version':1,'mode':'live','task':task,'context':context,'source_graph':graph,'source':source,'decision':decision,'patch_status':status,'patch_errors':errors,'updated_graph':updated,'updated':rerun,'usage':client.usage,'seconds':round(time.monotonic()-start,2),'evaluation':'No gold labels are used. Compare evidence and answers; a changed answer is not proof of improvement.'}
    emit('complete',result)
    return result
