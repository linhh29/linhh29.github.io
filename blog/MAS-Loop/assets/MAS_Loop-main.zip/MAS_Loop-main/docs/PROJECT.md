# MAS-Loop project overview

**Hehai Lin · Qi Yang · Chengwei Qin**  
HKUST (Guangzhou) · Ant Group  
Corresponding author: Chengwei Qin

## From construction to execution feedback

1. The Orchestrator creates a task-specific agent graph.
2. The source system executes, producing node outputs and a trajectory.
3. The Refiner diagnoses a weakness from that evidence and issues one bounded decision.
4. The compiler validates and applies the decision.
5. The updated system executes independently on the same task.

![Framework](assets/method.png)

[Read the manuscript](paper.pdf) · [Run inference](../inference/README.md) · [Research reproduction](../README_RESEARCH.md)

The companion `blog_mas_loop` package contains the complete English project website, including the abstract, contributions, experiments, ablations, case study, resources, and citation. The companion `MAS-Loop-Demo` serves that page at `/blog/` and the interactive lab at `/`. Public project URLs can be added when the artifacts are deployed.
