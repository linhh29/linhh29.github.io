<div align="center">

# MAS-Loop

### Beyond One-Shot Orchestration towards Self-Evolving Multi-Agent Systems

**[Hehai Lin](https://linhh29.github.io/)<sup>1</sup> · Qi Yang<sup>2</sup> · [Chengwei Qin](https://qcwthu.github.io/)<sup>1,†</sup>**

<sup>1</sup> HKUST (Guangzhou) &nbsp; <sup>2</sup> Ant Group  
<sup>†</sup> Corresponding author: Chengwei Qin

**[Paper](docs/paper.pdf) · [Project Overview](docs/PROJECT.md) · [Run Locally](inference/README.md) · [Research Guide](README_RESEARCH.md) · [Citation](#citation)**

Construct → Execute → Diagnose → Refine → Re-execute

</div>

---

## Overview

MAS-Loop connects multi-agent construction to execution feedback. An **Orchestrator** builds a source system. A **Refiner** inspects its trajectory, diagnoses a concrete weakness, and proposes one bounded intervention. The updated graph is independently executed on the same task to test the consequence.

During training, complementary rewards couple the two policies. At inference time, the same workflow produces a source–updated pair that can be inspected and compared.

![MAS-Loop framework](docs/assets/method.png)

### Highlights

- **Execution-grounded refinement:** cite observable agent outputs when diagnosing and editing a system.
- **One bounded decision:** accept, add an agent, rewrite a role, edit an edge, adjust a reasoning budget, or change a tool.
- **Paired evaluation:** compare independent source and updated executions.
- **Research resources:** original training, corpus construction, reward modeling, and test-time selection code are retained.

The supplied manuscript reports an average of **43.43%** over seven benchmarks with the Refiner, compared with **41.47%** for its source Orchestrator. These are research results; the API demonstration does not reproduce trained-checkpoint scores.

## Contents

- [Quick start](#quick-start)
- [Interactive demo and project page](#interactive-demo-and-project-page)
- [Research reproduction](#research-reproduction)
- [Repository layout](#repository-layout)
- [Validation](#validation)
- [Citation](#citation)
- [Acknowledgments and licensing](#acknowledgments-and-licensing)

## Quick start

**Python 3.10+ · no GPU · no third-party dependencies for the inference adapter**

```bash
cd inference
cp .env.example .env
# Set MAS_LOOP_API_KEY in .env.
python3 -m masloop_demo.cli \
  --task "How many integers from 1 to 100 are divisible by 3 or 5?" \
  --output run.json
```

Default API configuration follows the reference demo:

```dotenv
MAS_LOOP_BASE_URL=https://opencode.ai/zen/go/v1
MAS_LOOP_MODEL=deepseek-v4-flash
```

Optional: `--context-file references.txt`. The output JSON contains both graphs, node traces, the Refiner decision, compiler status, and provider-reported usage. The adapter runs prompted API policies, without training.

## Interactive demo and project page

The companion **MAS-Loop-Demo** distribution includes:

- a question library with 309 prompts from the supplied reference demo;
- a full-width task editor and an animated agent graph;
- streamed execution events, grounded patches, source/updated comparison, and JSON export;
- an annotated paper walkthrough that works without an API key;
- the English research project page, served at `/blog/`;
- Docker Compose and a Caddy deployment template.

Extract that distribution, configure its `.env`, then run `bash run.sh`. Open `http://127.0.0.1:9388`. The complete web application is packaged separately from this research repository.

## Research reproduction

See [README_RESEARCH.md](README_RESEARCH.md) for the original environment, training, evaluation, reward-model and test-time scaling instructions. Large datasets, retrieval indexes, trained policies and MAS-JudgeCorpus records are separate resources and were not included in the supplied archive.

The lightweight adapter uses the unchanged compiler from `verl/mas_loop_rl/schema.py`, with additional execution and evidence checks described in [PROVENANCE.md](inference/PROVENANCE.md).

## Repository layout

| Path | Purpose |
| --- | --- |
| `inference/` | API inference adapter, environment example, and focused tests |
| `formalize/` | Original graph representation and formalized execution pipeline |
| `building/`, `mas_loop/` | Original system construction and trajectory implementation |
| `verl/` | Distributed training backend and MAS-Loop integration |
| `MAS_JudgeCorpus/` | Corpus construction, reward-model training, and test-time selection |
| `docs/` | Manuscript, framework figure, and project overview |
| `README_RESEARCH.md` | Preserved original research instructions |

## Validation

```bash
cd inference
python3 -m unittest discover -s tests -v
```

The full Demo distribution also includes HTTP integration tests using a local mock provider. Real OpenCode testing requires a valid API key.

## Citation

```bibtex
@misc{masloop2026,
  title = {MAS-Loop: Beyond One-Shot Orchestration towards Self-Evolving Multi-Agent Systems},
  author = {Lin, Hehai and Yang, Qi and Qin, Chengwei},
  year = {2026},
  note = {Manuscript under review}
}
```

## Acknowledgments and licensing

The supplied research implementation builds on the bundled `verl` backend. Its existing license and notice files are retained. All 649 supplied research files are preserved; the original root README is stored as `README_RESEARCH.md`.

The supplied research archive had no top-level license. This packaging does not assign a new license to the research code, manuscript, or question datasets.
